import logo from './logo.svg';
import './App.css';
import { Routes, Route } from "react-router-dom";
import Products from "./Products.js";
import Detail from "./Detail.js";
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={ <Products/> } />
        <Route path="detail/:id" element={ <Detail/> } />
      </Routes>
    </div>
  );
}

export default App;
